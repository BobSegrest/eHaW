License Summary

* If you are just using eHaW and/or the eHaW Moderator, it's free, have fun

* If you modify the source code in this repository for use by anyone other than yourself, you have to provide your changes along with this source code code to anyone you sell or give the application to, if they ask for it.  And the conditions and obligations listed below need to be provided as part of what you provide.

Bob Segrest, KO2F
24-Sep-2022

-------------------------------------

The eHaW Moderator was created with and requires PyQt5/PyQt tools and distribution files to function.  The eHaW Moderator and eHaW (web application) are both built with MySQL driver code and require a MySQL server to function.  MySQL Community products are the property of Oracle and licensed under a GPL agreement that requires distribution of resulting source code.  The code in this public repository is intended to meet the source code availability requirements of both GPL and GNU General Public License v3.0 terms.

Any aspect of this source code not covered or constrained by the PyQt5/PyQt required GNU license, or the Oracle MySQL Community required GPL license, is granted under the terms of a common MIT license.

-------------------------------------

PyQt5/PyQt is licensed under the GNU General Public License v3.0
Permissions of this strong copyleft license are conditioned on making available complete source code of licensed works and modifications, which include larger works using a licensed work, under the same license. Copyright and license notices must be preserved. Contributors provide an express grant of patent rights.

For more detail, please see the full license text at

    https://github.com/PyQt5/PyQt/blob/master/LICENSE

-------------------------------------

MySQL Community products, Copyright (c) 2010, 2022, Oracle and/or its affiliates.

License information can be found in the Oacle LICENSE-GPL file. 
This distribution may include materials developed by third parties. For license 
and attribution notices for these materials, please refer to the Oracle LICENSE-GPL file. 

-------------------------------------

MIT License

Copyright (c) 2022 Bob Segrest

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

